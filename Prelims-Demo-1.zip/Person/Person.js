module.exports = function (firstName, lastName) {  

this.firstName = firstName;
this.lastName = lastname;
this.fullName = function () {
    return this.firstName + ' ' + this.lastName;
  }
}  
