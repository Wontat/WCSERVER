var myLongModule = require('./Log');

myLogModule.info('NodeJS is currently running...');