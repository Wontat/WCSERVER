//Bagang Andrei
//2075 - WCSERVER 
//Creating a function

function Display(x) {
  console.log(x)
}

Display(100);